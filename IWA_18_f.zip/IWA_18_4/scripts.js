import { createOrderData, state } from './data.js';
import { createOrderHtml, html } from './view.js'

/**
 * A handler that fires when a user drags over any element inside a column. In
 * order to determine which column the user is dragging over the entire event
 * bubble path is checked with `event.path` (or `event.composedPath()` for
 * browsers that don't support `event.path`). The bubbling path is looped over
 * until an element with a `data-area` attribute is found. Once found both the
 * active dragging column is set in the `state` object in "data.js" and the HTML
 * is updated to reflect the new column.
 *
 * @param {Event} event 
 */
const handleDragOver = (event) => {
    event.preventDefault();
    const path = event.path || event.composedPath()
    let column = null

    for (const element of path) {
        const { area } = element.dataset
        if (area) {
            column = area
            break;
        }
    }

    if (!column) return
    updateDragging({ over: column })
    updateDraggingHtml({ over: column })
}


const handleDragStart = (event) => { }
const handleDragEnd = (event) => { }
const handleHelpToggle = (event) => {
    const helpButton = document.querySelector('[data-help]');
    const helpOverlay = document.querySelector('[data-help-overlay]');
    const closeHelp = document.querySelector('[data-help-cancel]');
    const addButton = document.querySelector('#add-order');

    helpButton.addEventListener('click', () => {
        helpOverlay.showModal();
    });

    closeHelp.addEventListener('click', () => {
        helpOverlay.close();
        addButton.focus();
    });
}
const handleAddToggle = (event) => {
    const addOrderBtn = document.querySelector('#add-order');
    const addOrderOverlay = document.querySelector('[data-add-overlay]');
    const cancelOrderBtn = document.querySelector('[data-add-cancel]');


    addOrderBtn.addEventListener('keydown', (e) => {
        if (e.code === 'Space' || e.code === 'Enter') {
            event.preventDefault();
            // Call the function to add an order here
            addOrderOverlay.showModal();
        }
    });

    //closes the add order overlay
    cancelOrderBtn.addEventListener('click', () => {
        const formq = document.getElementById('add-form');
        formq.reset();
        addOrderOverlay.close();

        addButton.focus();
    });
}

const handleAddSubmit = (event) => {
    event.preventDefault();
    //get the values of the title and table to complete the order object 
    const form = document.getElementById('add-form');
    const title = form.elements.title.value;
    const table = form.elements.table.value;

    const column = 'ordered';

    //create the order object with the title, table and column
    const orderData = { title, table, column };

    //create the order using the createOrderData method 
    const order = createOrderData(orderData);

    //add the order to the current state
    state.orders[orderData.id] = orderData;

    //get the grid and the add overlay 
    const orderedGrid = document.querySelector('[data-column="ordered"]');
    const addOverlay = document.querySelector('[data-add-overlay]');

    //close the add overlay after adding the order
    addOverlay.close();

    //add the order to the ordered section
    const formq = document.getElementById('add-form');
    formq.reset();
    orderedGrid.appendChild(createOrderHtml(orderData));

}

const handleEditToggle = (event) => {
    event.preventDefault();
    const orderItem = event.target.closest('.order');

    if (orderItem) {
        // Get the order details
        const orderId = orderItem.dataset.id;
        const orderTitle = orderItem.querySelector('.order__title').textContent;
        const orderTable = orderItem.querySelector('.order__details').textContent;
        const orderColumn = orderItem.closest('.grid__column').dataset.area;

        // Show the edit order overlay with the order details
        const editOverlay = document.querySelector('[data-edit-overlay]');
        editOverlay.querySelector('[data-edit-id]').value = orderId;
        editOverlay.querySelector('[data-edit-title]').value = orderTitle;
        editOverlay.querySelector('[data-edit-table]').value = orderTable;
        editOverlay.querySelector('[data-edit-column]').value = orderColumn;
        editOverlay.showModal();
    }

}
const handleEditSubmit = (event) => { }
const handleDelete = (event) => {
    event.preventDefault();

}

html.add.cancel.addEventListener('click', handleAddToggle)
html.other.add.addEventListener('click', handleAddToggle)
html.add.form.addEventListener('submit', handleAddSubmit)

html.other.grid.addEventListener('click', handleEditToggle)
html.edit.cancel.addEventListener('click', handleEditToggle)
html.edit.form.addEventListener('submit', handleEditSubmit)
html.edit.delete.addEventListener('click', handleDelete)

html.help.cancel.addEventListener('click', handleHelpToggle)
html.other.help.addEventListener('click', handleHelpToggle)

for (const htmlColumn of Object.values(html.columns)) {
    htmlColumn.addEventListener('dragstart', handleDragStart)
    htmlColumn.addEventListener('dragend', handleDragEnd)
}

for (const htmlArea of Object.values(html.area)) {
    htmlArea.addEventListener('dragover', handleDragOver)
}