// alex.js

const firstname = "Alex"
const surname = "Naidoo"
const role = "Head of Marketing"

const display= firstname + " " + surname + " (" + role + ")"
document.querySelector('#alex').innerText = display