// scripts.js

import {role as nwabisaRole} from './nwabisa';
import {role as johannesRole} from './johannes.js';
import {role as alexRole} from './alex.js';



console.log('Roles:', nwabisaRole, johannesRole, alexRole)