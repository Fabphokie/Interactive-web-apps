// nwabisa.js

const firstname = "Nwabisa"
const surname = "Gabe"
const role = "CEO"

const display= firstname + " " + surname + " (" + role + ")"
document.querySelector('#nwabisa').innerText = display