// configuration.js

export const company = 'ACME Inc'
export const year = 2022
 
